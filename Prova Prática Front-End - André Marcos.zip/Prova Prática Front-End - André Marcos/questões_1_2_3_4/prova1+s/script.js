document.addEventListener('DOMContentLoaded', () => {
    const textoInput = document.getElementById('campo-texto');
    const totalCaracteres = document.getElementById('contador-caracteres');
    const totalPalavras = document.getElementById('contador-palavras');
    const nomeDesenvolvedor = document.getElementById('nome-desenvolvedor');

    function inserirNome() {
        nomeDesenvolvedor.textContent = 'Seu Nome Aqui';
    }
    inserirNome();

    textoInput.addEventListener('input', () => {
        const conteudo = textoInput.value;

        // Contar caracteres
        const numCaracteres = conteudo.length;
        totalCaracteres.textContent = numCaracteres;

        // Contar palavras
        const listaPalavras = conteudo.trim().split(/\s+/);
        const numPalavras = conteudo.trim() === '' ? 0 : listaPalavras.length;
        totalPalavras.textContent = numPalavras;
    });
});
